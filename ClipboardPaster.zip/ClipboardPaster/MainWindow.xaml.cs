﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using WindowsInput;
using WindowsInput.Native;

namespace SmartTablePaster
{
    public partial class MainWindow : Window
    {
        private InputSimulator _input = new InputSimulator();
        private CancellationTokenSource _cts;
        private bool _isProcessing;
        private int _currentRow;
        private int _currentCell;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += (s, e) => RefreshProcessList();
        }

        private async void StartPasting_Click(object sender, RoutedEventArgs e)
        {
            if (_isProcessing) return;

            try
            {
                _isProcessing = true;
                _cts = new CancellationTokenSource();
                UpdateStatus("جاري التحضير...", "#FF4CAF50");

                var table = ParseClipboardTable();
                var targetApp = GetTargetProcess();

                if (!ValidateInput(table, targetApp)) return;

                await ProcessTableAsync(table, targetApp.Value.Handle);
            }
            catch (Exception ex)
            {
                HandleError(ex);
            }
            finally
            {
                _isProcessing = false;
            }
        }

        private List<List<string>> ParseClipboardTable()
        {
            return Clipboard.GetText()
                .Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries)
                .Select(row => row.Split(new[] { '\t', '|', ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(cell => cell.Trim()).ToList())
                .Where(row => row.Count > 0)
                .ToList();
        }

        private Process? GetTargetProcess()
        {
            return Process.GetProcessesByName("التكاليف")
                .FirstOrDefault(p => !string.IsNullOrEmpty(p.MainWindowTitle));
        }

        private bool ValidateInput(List<List<string>> table, Process? targetApp)
        {
            var errors = new List<string>();
            
            if (table == null || table.Count == 0)
                errors.Add("لا يوجد جدول في الحافظة");
            
            if (targetApp == null)
                errors.Add("التطبيق الهدف غير مفتوح");
            
            if (errors.Any())
                MessageBox.Show(string.Join("\n", errors), "خطأ في الإدخال");
            
            return !errors.Any();
        }

        private async Task ProcessTableAsync(List<List<string>> table, IntPtr targetHandle)
        {
            await Task.Run(async () =>
            {
                SetForegroundWindow(targetHandle);
                _input.Keyboard.Sleep(500);

                for (_currentRow = 0; _currentRow < table.Count; _currentRow++)
                {
                    var row = table[_currentRow];
                    
                    for (_currentCell = 0; _currentCell < row.Count; _currentCell++)
                    {
                        if (_cts.IsCancellationRequested) return;
                        
                        await EnterCellData(row[_currentCell]);
                        NavigateToNextCell(_currentCell, row.Count);
                        
                        UpdateProgress(table);
                        await Task.Delay(GetDynamicDelay(row[_currentCell]));
                    }
                    
                    MoveToNextRow();
                }
            }, _cts.Token);
        }

        private async Task EnterCellData(string text)
        {
            await Application.Current.Dispatcher.InvokeAsync(() =>
            {
                _input.Keyboard.TextEntry(text)
                    .Sleep(20);
            });
        }

        private void NavigateToNextCell(int currentCell, int totalCells)
        {
            if (currentCell < totalCells - 1)
            {
                _input.Keyboard.KeyPress(VirtualKeyCode.TAB);
                return;
            }
            
            // للخلايا الأخيرة في الصف
            _input.Keyboard.KeyPress(VirtualKeyCode.RIGHT);
        }

        private void MoveToNextRow()
        {
            _input.Keyboard
                .KeyPress(VirtualKeyCode.RETURN)
                .KeyPress(VirtualKeyCode.HOME);
        }

        private int GetDynamicDelay(string text)
        {
            return Math.Clamp(100 - (text.Length * 2), 30, 150);
        }

        private void UpdateStatus(string message, string color = "#FF2196F3")
        {
            Dispatcher.Invoke(() =>
            {
                StatusText.Text = message;
                StatusBorder.Background = (SolidColorBrush)new BrushConverter().ConvertFromString(color);
            });
        }

        private void UpdateProgress(List<List<string>> table)
        {
            var progress = ((double)(_currentRow * 100) / table.Count) + 
                          ((double)_currentCell / (table[_currentRow].Count * 100));
            
            Dispatcher.Invoke(() =>
            {
                ProgressBar.Value = progress;
                ProgressText.Text = $"{progress:0}%";
            });
        }

        private void HandleError(Exception ex)
        {
            Dispatcher.Invoke(() =>
            {
                UpdateStatus("حدث خطأ!", "#FFf44336");
                MessageBox.Show($"خطأ: {ex.Message}\n{ex.StackTrace}");
            });
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            _cts?.Cancel();
            UpdateStatus("تم الإلغاء", "#FF9E9E9E");
        }

        private void RefreshProcessList()
        {
            // ... (كود تحديث قائمة العمليات)
        }

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);
    }
}