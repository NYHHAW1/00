using HtmlAgilityPack;
using System.Collections.Generic;

namespace ClipboardPaster.Core
{
    public class ClipboardParser
    {
        public Table Parse(string html)
        {
            var doc = new HtmlDocument();
            doc.LoadHtml(html);
            
            var table = new Table();
            foreach (var row in doc.DocumentNode.SelectNodes("//tr") ?? new HtmlAgilityPack.HtmlNodeCollection(null))
            {
checked
{
                    var currentRow =
}