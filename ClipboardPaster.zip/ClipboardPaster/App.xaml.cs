﻿using ClipboardPaster.Utilities;
using System.Windows;

namespace ClipboardPaster
{
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            LocalizationManager.SetArabic();
        }
    }
}