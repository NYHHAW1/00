using ClipboardPaster.Models;
using ClipboardPaster.Services;
using ClipboardPaster.Utilities;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;

namespace ClipboardPaster.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly AppConfig _config;
        private readonly TableParserService _parser;
        private readonly ProcessManagerService _processManager;
        private readonly InputSimulatorEx _input;

        public ICommand StartCommand { get; }
        public ICommand CancelCommand { get; }

        private double _progress;
        public double Progress
        {
            get => _progress;
            set => SetField(ref _progress, value, nameof(Progress));
        }

        public MainViewModel()
        {
            _config = AppConfig.Load();
            _parser = new TableParserService();
            _processManager = new ProcessManagerService();
            _input = new InputSimulatorEx();

            StartCommand = new RelayCommand(async () => await StartProcess());
            CancelCommand = new RelayCommand(CancelProcess);
        }

        private async Task StartProcess()
        {
            var table = _parser.Parse(Clipboard.GetText());
            var process = _processManager.FindTargetProcess(_config.TargetApp);
            
            if (process != null)
            {
                _processManager.ActivateWindow(process);
                await ProcessTable(table);
            }
        }

        private async Task ProcessTable(List<List<string>> table)
        {
            for (int row = 0; row < table.Count; row++)
            {
                for (int col = 0; col < table[row].Count; col++)
                {
                    _input.TypeText(table[row][col]);
                    _input.NavigateCell(col == table[row].Count - 1);
                    Progress = (double)(row * table[row].Count + col) / (table.Count * table[row].Count) * 100;
                    await Task.Delay(_config.Delay);
                }
            }
        }

        private void CancelProcess()
        {
            // إلغاء العملية
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        protected bool SetField<T>(ref T field, T value, string propertyName)
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool> _canExecute;

        public RelayCommand(Action execute, Func<bool> canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter) => _canExecute?.Invoke() ?? true;
        public void Execute(object parameter) => _execute();
        public event EventHandler CanExecuteChanged;
    }
}