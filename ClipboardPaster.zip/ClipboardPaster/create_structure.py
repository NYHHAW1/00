import os

project_structure = {
    "ClipboardPaster": {
        "Core": [
            "ClipboardParser.cs",
            "InputEngine.cs",
            "TableProcessor.cs"
        ],
        "Infrastructure": {
            "Services": [
                "ProcessService.cs",
                "UpdateService.cs"
            ],
            "Utilities": [
                "Logger.cs",
                "ConfigManager.cs"
            ]
        },
        "Presentation": {
            "ViewModels": [
                "MainViewModel.cs",
                "SettingsViewModel.cs"
            ],
            "Views": [
                "MainWindow.xaml",
                "SettingsWindow.xaml"
            ],
            "Converters": [
                "BoolToVisibilityConverter.cs"
            ]
        },
        "Domain": {
            "Models": [
                "AppConfig.cs",
                "TableData.cs"
            ],
            "Enums": [
                "NavigationMode.cs"
            ]
        },
        "Tests": [
            "ClipboardParserTests.cs",
            "InputEngineTests.cs"
        ],
        "Resources": {
            "Icons": [],
            "Languages": [],
            "Styles.xaml": []
        }
    }
}

def create_structure(base_path, structure):
    for name, content in structure.items():
        path = os.path.join(base_path, name)
        if isinstance(content, list):
            os.makedirs(path, exist_ok=True)
            for file in content:
                open(os.path.join(path, file), 'a').close()  # Create an empty file
        elif isinstance(content, dict):
            os.makedirs(path, exist_ok=True)
            create_structure(path, content)

# تحديد مسار المشروع
base_directory = "."  # يمكنك تغيير هذا المسار حسب الحاجة
create_structure(base_directory, project_structure)