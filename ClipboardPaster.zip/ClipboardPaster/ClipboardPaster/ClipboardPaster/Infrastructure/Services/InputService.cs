using WindowsInput;
using WindowsInput.Native;

namespace ClipboardPaster.Infrastructure.Services
{
    public interface IInputService
    {
        void SendText(string text);
        void PressTab();
    }

    public class InputService : IInputService
    {
        private readonly InputSimulator _input = new InputSimulator();
        
        public void SendText(string text) => _input.Keyboard.TextEntry(text);
        public void PressTab() => _input.Keyboard.KeyPress(VirtualKeyCode.TAB);
    }
}