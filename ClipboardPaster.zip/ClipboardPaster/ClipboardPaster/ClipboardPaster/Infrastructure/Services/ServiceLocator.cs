using Microsoft.Extensions.DependencyInjection;
using ClipboardPaster.Infrastructure.Services;
using ClipboardPaster.Presentation.ViewModels;

namespace ClipboardPaster
{
    public static class ServiceLocator
    {
        public static ServiceProvider Provider { get; private set; }

        public static void Configure()
        {
            var services = new ServiceCollection();
            
            services.AddSingleton<IClipboardService, ClipboardService>();
            services.AddSingleton<IInputService, InputService>();
            services.AddTransient<MainViewModel>();
            
            Provider = services.BuildServiceProvider();
        }
    }
}