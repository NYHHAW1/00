using ClipboardPaster.Core;
using System.Windows;

namespace ClipboardPaster.Infrastructure.Services
{
    public interface IClipboardService
    {
        Table GetTableData();
    }

    public class ClipboardService : IClipboardService
    {
        private readonly ClipboardParser _parser = new ClipboardParser();

        public Table GetTableData()
        {
            try { return _parser.Parse(Clipboard.GetText()); }
            catch { return new Table(); }
        }
    }
}