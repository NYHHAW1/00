using System.Collections.Generic;

namespace ClipboardPaster.Core
{
    public class Table
    {
        public List<List<string>> Rows { get; } = new List<List<string>>();
    }
}