using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace ClipboardPaster.Presentation.Converters
{
    public interface IBoolToVisibilityConverter
    {
        global::System.Object Convert(global::System.Object value, Type targetType, global::System.Object parameter, CultureInfo culture);
        global::System.Object ConvertBack(global::System.Object value, Type targetType, global::System.Object parameter, CultureInfo culture);
    }

    public interface IBoolToVisibilityConverter1
    {
        global::System.Object Convert(global::System.Object value, Type targetType, global::System.Object parameter, CultureInfo culture);
        global::System.Object ConvertBack(global::System.Object value, Type targetType, global::System.Object parameter, CultureInfo culture);
    }

    public interface IBoolToVisibilityConverter2
    {
        global::System.Object Convert(global::System.Object value, Type targetType, global::System.Object parameter, CultureInfo culture);
        global::System.Object ConvertBack(global::System.Object value, Type targetType, global::System.Object parameter, CultureInfo culture);
    }

    public interface IBoolToVisibilityConverter3
    {
        global::System.Object Convert(global::System.Object value, Type targetType, global::System.Object parameter, CultureInfo culture);
        global::System.Object ConvertBack(global::System.Object value, Type targetType, global::System.Object parameter, CultureInfo culture);
    }

    public class BoolToVisibilityConverter : IValueConverter, IBoolToVisibilityConverter, IBoolToVisibilityConverter1, IBoolToVisibilityConverter2, IBoolToVisibilityConverter3
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => (value is bool b && b) ? Visibility.Visible : Visibility.Collapsed;

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}