using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ClipboardPaster.Core;
using ClipboardPaster.Infrastructure.Services;
using System.Threading.Tasks;

namespace ClipboardPaster.Presentation.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        private readonly IClipboardService _clipboardService;
        private readonly IInputService _inputService;

        [ObservableProperty]
        private string _statusMessage = "جاهز";

        [ObservableProperty]
        private bool _isProcessing;

        public MainViewModel(IClipboardService clipboardService, IInputService inputService)
        {
            _clipboardService = clipboardService;
            _inputService = inputService;
        }

        [RelayCommand]
        private async Task ProcessDataAsync()
        {
            IsProcessing = true;
            StatusMessage = "جاري تحليل البيانات...";
            
            var table = _clipboardService.GetTableData();
            
            StatusMessage = "جاري الإدخال...";
            await Task.Run(() => ProcessTable(table));
            
            StatusMessage = "تم الانتهاء!";
            IsProcessing = false;
        }

        private void ProcessTable(Table table)
        {
            foreach (var row in table.Rows)
            {
                foreach (var cell in row)
                {
                    _inputService.SendText(cell);
                    _inputService.PressTab();
                }
            }
        }
    }
}
using System.Diagnostics; // أضف هذا السطر

public partial class MainViewModel : ObservableObject
{
    public MainViewModel(IClipboardService clipboardService, IInputService inputService)
    {
        _clipboardService = clipboardService;
        _inputService = inputService;
        Debug.WriteLine("تم تهيئة ViewModel بنجاح"); // تسجيل بدء التهيئة
    }

    [RelayCommand]
    private async Task ProcessDataAsync()
    {
        try
        {
            Debug.WriteLine("بدء عملية المعالجة...");
            
            IsProcessing = true;
            StatusMessage = "جاري تحليل البيانات...";
            
            var table = _clipboardService.GetTableData();
            Debug.WriteLine($"تم تحليل جدول بـ {table.Rows.Count} صفوف"); // عدد الصفوف
            
            StatusMessage = "جاري الإدخال...";
            await Task.Run(() => ProcessTable(table));
            
            StatusMessage = "تم الانتهاء!";
            Debug.WriteLine("العملية اكتملت بنجاح");
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"حدث خطأ: {ex.Message}"); // تسجيل الأخطاء
            StatusMessage = "حدث خطأ أثناء المعالجة";
        }
        finally
        {
            IsProcessing = false;
        }
    }
}